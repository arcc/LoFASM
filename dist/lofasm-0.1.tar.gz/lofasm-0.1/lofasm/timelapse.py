#timelapse script


#get file list

#read header & convert mjd -> LST

#average over range of fft bins

#plot power VS LST
